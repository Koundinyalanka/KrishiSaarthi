import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, ViewController } from 'ionic-angular';


import * as HighCharts from 'highcharts';

//Provider
import { FinancialProvider } from '../../providers/financial/financial';

@IonicPage()
@Component({
  selector: 'page-insight',
  templateUrl: 'insight.html',
})
export class InsightPage {

  constructor(public navCtrl: NavController,
              public navParams: NavParams,
              private fService: FinancialProvider,
              private viewCtrl: ViewController) {
  }

  ionViewDidLoad() {
    this.loadChart()
  }

  loadFinancial(){
    this.fService.getInsightdata().subscribe(res =>{
      console.log('res')
    })
  }

  loadChart(){
    var myChart = HighCharts.chart('container', {
      chart: {
      type: 'bar'
      },
      title: {
      text: 'Fruit Consumption'
      },
      xAxis: {
      categories: ['Apples', 'Bananas', 'Oranges']
      },
      yAxis: {
      title: {
      text: 'Fruit eaten'
      }
      },
      series: [{
      name: 'Jane',
      data: [1, 0, 4]
      }, {
      name: 'John',
      data: [5, 7, 3]
      }]
      });
  }

  dismiss(){
    this.viewCtrl.dismiss();
  }

}
