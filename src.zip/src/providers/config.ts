import { Injectable } from '@angular/core';

@Injectable()
export class NasscomConfig {
  cropUrl: string = 'http://18.236.107.196:3003/';
}